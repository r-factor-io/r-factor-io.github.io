# r-factor README

R-Factor - React & Redux Refactoring Tools

## Features

For full list of features see https://r-factor.io/

## Requirements

- node.js 6.0.0+

## Extension Settings

For full list of settings & documentation see https://r-factor.io/documentation/
